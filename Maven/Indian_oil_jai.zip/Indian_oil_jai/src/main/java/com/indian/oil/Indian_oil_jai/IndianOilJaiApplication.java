package com.indian.oil.Indian_oil_jai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndianOilJaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndianOilJaiApplication.class, args);
	}

}
