package com.indian.oil.Indian_oil_jai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndianOilJaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
