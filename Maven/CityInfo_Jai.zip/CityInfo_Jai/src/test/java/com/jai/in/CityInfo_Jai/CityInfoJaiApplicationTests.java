package com.jai.in.CityInfo_Jai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityInfoJaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
