package com.jai.in.CityInfo_Jai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityInfoJaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityInfoJaiApplication.class, args);
	}

}
