package com.keserai.keseari2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Keseari2Application {

	public static void main(String[] args) {
		SpringApplication.run(Keseari2Application.class, args);
	}

}
